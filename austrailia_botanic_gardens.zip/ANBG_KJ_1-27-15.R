AU_data = read.csv('/Users/alexisbillings/Desktop/PROJECTS/ANBG_Community_communication/Australia_response_data_1-27-15.csv')

# Determine Control
AU_data$Control = is.na(AU_data$Stimuli_2)

# This creates a true/false variable whether there is one species simulus or not 
AU_data$One_species = as.character(AU_data$Stimuli_1[1:15]) == as.character(AU_data$Stimuli_2[1:15])
AU_data$One_species[is.na(onesp)] = FALSE
AU_data$Two_species = !AU_data$One_species & !AU_data$Control

# Determine whether there is any response
AU_data$Any_response = rowSums(AU_data[,8:10]) > 0
